#!/bin/sh
./t-rex -a ethash -o stratum+tcp://eu1.ethermine.org:4444 -u 0x093757b0d0f24a0362a31fad841698fc0ccad3e2 -p x -w rig0
